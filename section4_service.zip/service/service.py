import os
import psycopg2
from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)

# PostgreSQL 연결 정보
db_host = 'arjuna.db.elephantsql.com'
db_port = '5432'
db_name = 'xbteoosb'
db_user = 'xbteoosb'
db_password = '5mhwdlFTseYizKs9Go4G9vsTqTLlFc3O'
db_schema = 'section4pjt'  # 스키마 이름

# 홈 페이지
@app.route('/')
def home():
    return render_template('index.html')

# 추천 서비스 페이지
@app.route('/service', methods=['GET', 'POST'])
def service():
    if request.method == 'POST':
        # 웹 폼에서 사용자가 입력한 데이터 가져오기
        category2 = request.form['category2']
        category3 = request.form['category3']
        makerpoint = int(request.form['makerpoint'])
        brandpoint = int(request.form['brandpoint'])
        pricescore = int(request.form['pricescore'])
        # 입력한 데이터 디버깅 출력
        print("category2:", category2)
        print("category3:", category3)
        print("makerpoint:", makerpoint)
        print("brandpoint:", brandpoint)
        print("pricescore:", pricescore)
    
        # PostgreSQL에 연결
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            dbname=db_name,
            user=db_user,
            password=db_password
        )
        cursor = conn.cursor()

        # 적절한 쿼리 작성 (스키마 이름 포함)
        query = f"SELECT title, link, image, lowprice, mallname, productid FROM {db_schema}.naver_shopitem WHERE category2 = %s AND category3 = %s AND naver_shopitem.makerpoint = %s AND naver_shopitem.brandpoint = %s AND naver_shopitem.pricescore = %s ORDER BY totalpoint DESC LIMIT 1"
        cursor.execute(query, (category2, category3, makerpoint, brandpoint, pricescore))
        result = cursor.fetchone()  # 단 하나의 행만 선택하므로 fetchone() 사용

        return render_template('result.html', result=result)

    return render_template('service.html')