from flask import Flask, render_template, request
import service
import recommend
import feedback

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/service', methods=['GET', 'POST'])
def handle_service():
    return service.service()

@app.route('/recommend', methods=['GET', 'POST'])
def handle_recommend():
    return recommend.service()

app.register_blueprint(feedback.bp)

if __name__ == '__main__':
    app.run(port=5001, debug=True)
