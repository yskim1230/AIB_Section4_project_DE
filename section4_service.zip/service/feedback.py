import psycopg2
from flask import Blueprint, render_template, request

bp = Blueprint('feedback', __name__)

# PostgreSQL 연결 설정
def connect_to_db():
    conn = psycopg2.connect(
        host="arjuna.db.elephantsql.com",
        port="5432",
        database="xbteoosb",
        user="xbteoosb",
        password="5mhwdlFTseYizKs9Go4G9vsTqTLlFc3O"
    )
    return conn

# Feedback 처리를 위한 핸들러
@bp.route('/feedback', methods=['POST'])
def handle_feedback():
    feedback = request.form.get('feedback')

    if feedback == 'yes':
        # PostgreSQL에 결과값 삽입
        conn = connect_to_db()
        cur = conn.cursor()
        result = request.form.getlist('result')  # service.html에서 전송된 결과값 리스트
        result.append(1)  # 상품 추천 여부를 1로 설정 (예: 추천)
        insert_query = "INSERT INTO section4pjt.feedback (productid, recommend) VALUES (%s, %s)"
        cur.execute(insert_query, tuple(result))
        conn.commit()
        cur.close()
        conn.close()

    return render_template('feedback.html')

@bp.route('/feedback-page', methods=['GET'])
def feedback_page():
    return render_template('feedback.html')


